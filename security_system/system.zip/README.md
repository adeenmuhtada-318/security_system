# SecureForce Management System

SecureForce is a robust, end-to-end management platform designed for security firms. It provides a comprehensive suite of tools to manage personnel, track attendance with integrated fine management, automate payroll based on performance, and monitor inventory levels with automated stock alerts.

## 🚀 Key Features

- **Centralized Dashboard**: Real-time stats on guard strength, duty status, and inventory alerts.
- **Personnel Management**: Add, view, and archive security personnel with detailed profiles (CNIC, Blood Group, Emergency Contacts).
- **Dynamic Shift Assignment**: Quickly reassign guards between Morning, Evening, and Night shifts.
- **Smart Attendance Grid**: Daily register with integrated fine toggles for Uniform, Weapon, Late, and Conduct violations.
- **Automated Payroll**: One-click monthly salary generation that auto-calculates deductions for absents and accumulated fines.
- **Inventory Hub**: Categorized asset tracking (Weapons, Office Gear, Logistics) with critical stock threshold warnings.
- **Responsive Cyber-Noir UI**: A modern, high-contrast interface designed for clarity in security operations centers.

## 🛠️ Tech Stack

- **Backend**: PHP 8.x (PDO for secure database interactions)
- **Frontend**: HTML5, CSS3 (Vanilla), JavaScript (Vanilla ES6)
- **Database**: MySQL / MariaDB
- **Design**: Cyber-Noir Aesthetic with 'Rajdhani' and 'Inter' typography.

## 📁 Project Structure

```text
security_system/
├── index.php               # Entry point (Redirects to Dashboard)
├── dashboard.php           # Main Command Center
├── attendance_grid.php     # Daily Attendance & Fines
├── payroll_hub.php         # Salary & Payout Management
├── inventory_hub.php       # Asset & Stock Management
├── database.sql            # Database Schema & Sample Data
├── api/
│   └── api_router.php      # Central API for JS fetch() calls
├── css/
│   └── style.css           # Global Stylesheet
├── includes/
│   ├── db_connect.php      # PDO Connection Utility
│   └── nav.php             # Shared Sidebar Navigation
└── js/
    ├── app.js              # Global Utilities & UI Logic
    ├── dashboard.js        # Dashboard Specific logic
    ├── attendance.js       # Attendance logic & Calculations
    ├── payroll.js         # Payroll generation & Payment
    └── inventory.js        # Inventory updates & Archiving
```

## ⚙️ Installation

1.  **Clone the Repository**: Place the project folder in your local server directory (e.g., `C:/xampp/htdocs/`).
2.  **Setup Database**:
    -   Open **phpMyAdmin**.
    -   Create a database named `security_firm`.
    -   Import the `database.sql` file.
3.  **Configure Connection**:
    -   Open `includes/db_connect.php`.
    -   Update `DB_USER` and `DB_PASS` if your MySQL configuration is different from the defaults.
4.  **Launch**:
    -   Start Apache and MySQL in XAMPP.
    -   Navigate to `http://localhost/security_system` in your browser.

---

# 💻 Complete Source Code

Below is the complete source code for every file in the project.

## 1. Root Files

### index.php
```php
<?php
// =====================================================
// INDEX - Redirect to dashboard
// =====================================================
header("Location: dashboard.php");
exit;
?>
```

### dashboard.php
```php
<?php
// =====================================================
// DASHBOARD - dashboard.php
// Main command center with stats, hiring, guard roster
// =====================================================
require_once 'includes/db_connect.php';
$db = getConnection();

// ---- Fetch live stats from database ----
$TotalGuards   = $db->query("SELECT COUNT(*) FROM Guards WHERE IsArchived = 0 AND Status = 'Active'")->fetchColumn();
$OnDutyGuards  = $db->query("SELECT COUNT(*) FROM Guards WHERE IsArchived = 0 AND CurrentShift != 'Off Duty' AND Status = 'Active'")->fetchColumn();
$TodayAbsents  = $db->query("SELECT COUNT(*) FROM Attendance WHERE AttendanceDate = CURDATE() AND IsPresent = 0")->fetchColumn();
$TotalItems    = $db->query("SELECT COUNT(*) FROM Inventory WHERE IsArchived = 0")->fetchColumn();
$LowStockItems = $db->query("SELECT COUNT(*) FROM Inventory WHERE IsArchived = 0 AND Quantity < MinThreshold")->fetchColumn();

// ---- Fetch all active guards for roster ----
$Guards = $db->query("SELECT * FROM Guards WHERE IsArchived = 0 ORDER BY FullName ASC")->fetchAll();

// ---- Handle Add Guard form submission ----
$SuccessMsg = '';
$ErrorMsg   = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['FormAction']) && $_POST['FormAction'] === 'AddGuard') {
    $Name          = trim($_POST['FullName'] ?? '');
    $CNIC          = trim($_POST['CNIC'] ?? '');
    $Phone         = trim($_POST['Phone'] ?? '');
    $Emergency     = trim($_POST['EmergencyPhone'] ?? '');
    $Blood         = $_POST['BloodGroup'] ?? '';
    $Address       = trim($_POST['Address'] ?? '');
    $JoiningDate   = $_POST['JoiningDate'] ?? '';

    if ($Name && $CNIC && $JoiningDate) {
        try {
            $stmt = $db->prepare("
                INSERT INTO Guards (FullName, CNIC, Phone, EmergencyPhone, BloodGroup, Address, JoiningDate)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([$Name, $CNIC, $Phone, $Emergency, $Blood, $Address, $JoiningDate]);
            $SuccessMsg = "Guard \"$Name\" has been successfully added to the system!";
            // Refresh page data
            header("Location: dashboard.php?added=1");
            exit;
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) {
                $ErrorMsg = "A guard with this CNIC already exists.";
            } else {
                $ErrorMsg = "Something went wrong. Please try again.";
            }
        }
    } else {
        $ErrorMsg = "Please fill in all required fields (Name, CNIC, Joining Date).";
    }
}

// ---- Handle shift change ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['FormAction']) && $_POST['FormAction'] === 'ChangeShift') {
    $GuardID  = (int)($_POST['GuardID'] ?? 0);
    $NewShift = $_POST['NewShift'] ?? '';
    $Allowed  = ['Morning', 'Evening', 'Night', 'Off Duty'];

    if ($GuardID && in_array($NewShift, $Allowed)) {
        $stmt = $db->prepare("UPDATE Guards SET CurrentShift = ? WHERE GuardID = ?");
        $stmt->execute([$NewShift, $GuardID]);
        header("Location: dashboard.php?shifted=1");
        exit;
    }
}

// ---- Handle archive guard ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['FormAction']) && $_POST['FormAction'] === 'ArchiveGuard') {
    $GuardID = (int)($_POST['GuardID'] ?? 0);
    if ($GuardID) {
        $db->prepare("UPDATE Guards SET IsArchived = 1, Status = 'Inactive' WHERE GuardID = ?")->execute([$GuardID]);
        header("Location: dashboard.php?archived=1");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard | SecureForce</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="AppShell">

    <?php include 'includes/nav.php'; ?>

    <main class="MainContent">

        <!-- Top Bar -->
        <div class="TopBar">
            <div class="TopBarTitle">🏠 Command Dashboard</div>
            <div class="TopBarRight">
                <div class="TopBarDate">
                    <span class="StatusDot"></span>
                    <span id="CurrentDateTime">Loading...</span>
                </div>
                <button class="Btn BtnPrimary" onclick="OpenModal('AddGuardModal')">
                    ➕ Add New Guard
                </button>
            </div>
        </div>

        <div class="PageContent">

            <!-- Alerts -->
            <?php if (isset($_GET['added'])): ?>
                <div class="AlertBox AlertSuccess">✅ New guard has been added successfully!</div>
            <?php endif; ?>
            <?php if (isset($_GET['shifted'])): ?>
                <div class="AlertBox AlertSuccess">✅ Guard shift has been updated!</div>
            <?php endif; ?>
            <?php if ($ErrorMsg): ?>
                <div class="AlertBox AlertDanger">❌ <?= htmlspecialchars($ErrorMsg) ?></div>
            <?php endif; ?>

            <!-- Live Stats Cards -->
            <div class="StatsGrid">

                <div class="StatCard" style="--CardAccent: #FF9800;">
                    <div class="StatCardIcon" style="background: rgba(255,152,0,0.12); font-size: 24px;">👮</div>
                    <div class="StatCardBody">
                        <div class="StatValue"><?= $TotalGuards ?></div>
                        <div class="StatLabel">Total Guards</div>
                    </div>
                </div>

                <div class="StatCard" style="--CardAccent: #4CAF50;">
                    <div class="StatCardIcon" style="background: rgba(76,175,80,0.12); font-size: 24px;">🟢</div>
                    <div class="StatCardBody">
                        <div class="StatValue"><?= $OnDutyGuards ?></div>
                        <div class="StatLabel">Currently On Duty</div>
                    </div>
                </div>

                <div class="StatCard" style="--CardAccent: #F44336;">
                    <div class="StatCardIcon" style="background: rgba(244,67,54,0.12); font-size: 24px;">❌</div>
                    <div class="StatCardBody">
                        <div class="StatValue"><?= $TodayAbsents ?></div>
                        <div class="StatLabel">Today's Absents</div>
                    </div>
                </div>

                <div class="StatCard" style="--CardAccent: #5B7F95;">
                    <div class="StatCardIcon" style="background: rgba(91,127,149,0.12); font-size: 24px;">📦</div>
                    <div class="StatCardBody">
                        <div class="StatValue"><?= $TotalItems ?></div>
                        <div class="StatLabel">Inventory Items</div>
                    </div>
                </div>

                <?php if ($LowStockItems > 0): ?>
                <div class="StatCard" style="--CardAccent: #F44336;">
                    <div class="StatCardIcon" style="background: rgba(244,67,54,0.12); font-size: 24px;">⚠️</div>
                    <div class="StatCardBody">
                        <div class="StatValue" style="color: #F44336;"><?= $LowStockItems ?></div>
                        <div class="StatLabel">Low Stock Alerts</div>
                    </div>
                </div>
                <?php endif; ?>

            </div>

            <!-- Guard Roster Table -->
            <div class="SectionPanel">
                <div class="SectionHeader">
                    <div class="SectionTitle">👥 Guard Roster</div>
                    <span class="Badge BadgeBlue"><?= count($Guards) ?> Guards</span>
                </div>

                <div style="overflow-x: auto;">
                    <table class="DataTable">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Guard Name</th>
                                <th>CNIC</th>
                                <th>Phone</th>
                                <th>Blood Group</th>
                                <th>Joining Date</th>
                                <th>Current Shift</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($Guards)): ?>
                                <tr>
                                    <td colspan="9">
                                        <div class="EmptyState">
                                            <div class="EmptyIcon">👮</div>
                                            <p>No guards in the system yet. Add your first guard!</p>
                                        </div>
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($Guards as $Index => $Guard): ?>
                                <tr>
                                    <td style="color: var(--ColorTextMuted);"><?= $Index + 1 ?></td>
                                    <td>
                                        <strong style="cursor: pointer; color: var(--ColorAccentGold);"
                                            onclick="ViewGuardProfile(<?= $Guard['GuardID'] ?>)">
                                            <?= htmlspecialchars($Guard['FullName']) ?>
                                        </strong>
                                    </td>
                                    <td style="font-family: monospace; font-size: 12px;"><?= htmlspecialchars($Guard['CNIC']) ?></td>
                                    <td><?= htmlspecialchars($Guard['Phone']) ?></td>
                                    <td>
                                        <span class="Badge BadgeWarning"><?= htmlspecialchars($Guard['BloodGroup']) ?></span>
                                    </td>
                                    <td><?= htmlspecialchars($Guard['JoiningDate']) ?></td>
                                    <td>
                                        <?php
                                            $ShiftClass = match($Guard['CurrentShift']) {
                                                'Morning'  => 'Badge ShiftMorning',
                                                'Evening'  => 'Badge ShiftEvening',
                                                'Night'    => 'Badge ShiftNight',
                                                default    => 'Badge ShiftOff'
                                            };
                                            $ShiftIcon = match($Guard['CurrentShift']) {
                                                'Morning'  => '🌅',
                                                'Evening'  => '🌆',
                                                'Night'    => '🌙',
                                                default    => '🔴'
                                            };
                                        ?>
                                        <span class="<?= $ShiftClass ?>">
                                            <?= $ShiftIcon ?> <?= $Guard['CurrentShift'] ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="Badge <?= $Guard['Status'] === 'Active' ? 'BadgeSuccess' : 'BadgeMuted' ?>">
                                            <?= $Guard['Status'] ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div style="display: flex; gap: 6px; flex-wrap: wrap;">
                                            <button class="Btn BtnSecondary BtnSmall"
                                                onclick="ViewGuardProfile(<?= $Guard['GuardID'] ?>)">
                                                👁 View
                                            </button>
                                            <button class="Btn BtnSuccess BtnSmall"
                                                onclick="OpenShiftModal(<?= $Guard['GuardID'] ?>, '<?= htmlspecialchars($Guard['FullName']) ?>')">
                                                🔄 Shift
                                            </button>
                                            <button class="Btn BtnDanger BtnSmall"
                                                onclick="ArchiveGuard(<?= $Guard['GuardID'] ?>, '<?= htmlspecialchars($Guard['FullName']) ?>')">
                                                🗃 Archive
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div><!-- /PageContent -->
    </main>
</div>

<!-- =====================================================
     MODAL: Add New Guard
     ===================================================== -->
<div class="ModalOverlay" id="AddGuardModal">
    <div class="ModalCard">
        <div class="ModalHeader">
            <div class="ModalTitle">➕ Add New Guard</div>
            <button class="ModalClose" onclick="CloseModal('AddGuardModal')">✕</button>
        </div>
        <div class="ModalBody">
            <form method="POST" action="dashboard.php">
                <input type="hidden" name="FormAction" value="AddGuard">

                <div class="FormRow">
                    <div class="FormGroup">
                        <label class="FormLabel">Full Name *</label>
                        <input type="text" name="FullName" class="FormControl" placeholder="e.g. Muhammad Ali" required>
                    </div>
                    <div class="FormGroup">
                        <label class="FormLabel">CNIC *</label>
                        <input type="text" name="CNIC" class="FormControl" placeholder="35201-1234567-1" required>
                    </div>
                </div>

                <div class="FormRow">
                    <div class="FormGroup">
                        <label class="FormLabel">Phone Number</label>
                        <input type="text" name="Phone" class="FormControl" placeholder="0300-1234567">
                    </div>
                    <div class="FormGroup">
                        <label class="FormLabel">Emergency Contact</label>
                        <input type="text" name="EmergencyPhone" class="FormControl" placeholder="0301-1234567">
                    </div>
                </div>

                <div class="FormRow">
                    <div class="FormGroup">
                        <label class="FormLabel">Blood Group</label>
                        <select name="BloodGroup" class="FormControl">
                            <option value="">Select...</option>
                            <option>A+</option><option>A-</option>
                            <option>B+</option><option>B-</option>
                            <option>O+</option><option>O-</option>
                            <option>AB+</option><option>AB-</option>
                        </select>
                    </div>
                    <div class="FormGroup">
                        <label class="FormLabel">Joining Date *</label>
                        <input type="date" name="JoiningDate" class="FormControl" required>
                    </div>
                </div>

                <div class="FormGroup" style="margin-bottom: 20px;">
                    <label class="FormLabel">Home Address</label>
                    <input type="text" name="Address" class="FormControl" placeholder="City, Province">
                </div>

                <div style="display: flex; gap: 10px;">
                    <button type="submit" class="Btn BtnPrimary BtnFull">✅ Add Guard to System</button>
                    <button type="button" class="Btn BtnSecondary" onclick="CloseModal('AddGuardModal')">Cancel</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- =====================================================
     MODAL: Guard Profile View
     ===================================================== -->
<div class="ModalOverlay" id="GuardProfileModal">
    <div class="ModalCard">
        <div class="ModalHeader">
            <div class="ModalTitle">👮 Guard Profile</div>
            <button class="ModalClose" onclick="CloseModal('GuardProfileModal')">✕</button>
        </div>
        <div class="ModalBody" id="GuardProfileBody">
            <div class="Spinner"></div>
        </div>
    </div>
</div>

<!-- =====================================================
     MODAL: Change Shift
     ===================================================== -->
<div class="ModalOverlay" id="ShiftModal">
    <div class="ModalCard" style="max-width: 380px;">
        <div class="ModalHeader">
            <div class="ModalTitle">🔄 Change Shift</div>
            <button class="ModalClose" onclick="CloseModal('ShiftModal')">✕</button>
        </div>
        <div class="ModalBody">
            <p style="color: var(--ColorTextSecondary); margin-bottom: 18px; font-size: 14px;">
                Assigning new shift for: <strong id="ShiftGuardName" style="color: var(--ColorAccentGold);"></strong>
            </p>
            <form method="POST" action="dashboard.php">
                <input type="hidden" name="FormAction" value="ChangeShift">
                <input type="hidden" name="GuardID" id="ShiftGuardID">

                <div class="FormGroup" style="margin-bottom: 20px;">
                    <label class="FormLabel">Select New Shift</label>
                    <select name="NewShift" class="FormControl">
                        <option value="Morning">🌅 Morning Shift</option>
                        <option value="Evening">🌆 Evening Shift</option>
                        <option value="Night">🌙 Night Shift</option>
                        <option value="Off Duty">🔴 Off Duty (Relieve)</option>
                    </select>
                </div>

                <div style="display: flex; gap: 10px;">
                    <button type="submit" class="Btn BtnPrimary BtnFull">✅ Update Shift</button>
                    <button type="button" class="Btn BtnSecondary" onclick="CloseModal('ShiftModal')">Cancel</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Hidden form for archive action -->
<form id="ArchiveForm" method="POST" action="dashboard.php" style="display:none;">
    <input type="hidden" name="FormAction" value="ArchiveGuard">
    <input type="hidden" name="GuardID" id="ArchiveGuardID">
</form>

<script src="js/app.js"></script>
<script src="js/dashboard.js"></script>
</body>
</html>
```

### attendance_grid.php
```php
<?php
// =====================================================
// ATTENDANCE GRID - attendance_grid.php
// Daily attendance sheet with fines management
// =====================================================
require_once 'includes/db_connect.php';
$db = getConnection();

// ---- Get date to view (default: today) ----
$ViewDate = $_GET['date'] ?? date('Y-m-d');

// ---- Make sure all active guards have an attendance record for this date ----
$ActiveGuards = $db->query("SELECT GuardID FROM Guards WHERE IsArchived = 0 AND Status = 'Active'")->fetchAll();
foreach ($ActiveGuards as $G) {
    $Check = $db->prepare("SELECT AttendanceID FROM Attendance WHERE GuardID = ? AND AttendanceDate = ?");
    $Check->execute([$G['GuardID'], $ViewDate]);
    if (!$Check->fetch()) {
        $db->prepare("INSERT INTO Attendance (GuardID, AttendanceDate) VALUES (?, ?)")
           ->execute([$G['GuardID'], $ViewDate]);
    }
}

// ---- Fetch attendance records for the selected date ----
$AttendanceList = $db->prepare("
    SELECT a.*, g.FullName, g.CurrentShift
    FROM Attendance a
    JOIN Guards g ON a.GuardID = g.GuardID
    WHERE a.AttendanceDate = ? AND g.IsArchived = 0
    ORDER BY g.FullName ASC
");
$AttendanceList->execute([$ViewDate]);
$Records = $AttendanceList->fetchAll();

// ---- Summary counts ----
$TotalPresent = 0;
$TotalAbsent  = 0;
$TotalFines   = 0;
foreach ($Records as $R) {
    if ($R['IsPresent']) $TotalPresent++; else $TotalAbsent++;
    $TotalFines += $R['TotalFine'];
}

// Fine amounts (fixed by admin)
$FineAmounts = [
    'UniformFine'  => 500,
    'WeaponFine'   => 1000,
    'LateFine'     => 300,
    'ConductFine'  => 500
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daily Attendance | SecureForce</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="AppShell">
    <?php include 'includes/nav.php'; ?>

    <main class="MainContent">

        <div class="TopBar">
            <div class="TopBarTitle">📋 Daily Attendance Sheet</div>
            <div class="TopBarRight">
                <div class="TopBarDate">
                    <span class="StatusDot"></span>
                    <span id="CurrentDateTime"></span>
                </div>
            </div>
        </div>

        <div class="PageContent">

            <!-- Date Selector & Stats -->
            <div class="SectionPanel" style="margin-bottom: 20px;">
                <div class="SectionBody" style="padding: 16px 22px;">
                    <div style="display: flex; align-items: center; gap: 16px; flex-wrap: wrap;">
                        <div style="display: flex; align-items: center; gap: 10px;">
                            <label class="FormLabel" style="margin: 0; white-space: nowrap;">📅 View Date:</label>
                            <input type="date" id="DatePicker" class="FormControl" style="width: auto;"
                                value="<?= htmlspecialchars($ViewDate) ?>"
                                onchange="window.location.href='attendance_grid.php?date=' + this.value">
                        </div>
                        <div style="display: flex; gap: 12px; flex-wrap: wrap; margin-left: auto;">
                            <div style="text-align: center; padding: 8px 20px; background: rgba(76,175,80,0.1); border-radius: 8px; border: 1px solid rgba(76,175,80,0.3);">
                                <div style="font-family: var(--FontDisplay); font-size: 22px; font-weight: 700; color: #4CAF50;"><?= $TotalPresent ?></div>
                                <div style="font-size: 11px; color: var(--ColorTextMuted); text-transform: uppercase;">Present</div>
                            </div>
                            <div style="text-align: center; padding: 8px 20px; background: rgba(244,67,54,0.1); border-radius: 8px; border: 1px solid rgba(244,67,54,0.3);">
                                <div style="font-family: var(--FontDisplay); font-size: 22px; font-weight: 700; color: #F44336;"><?= $TotalAbsent ?></div>
                                <div style="font-size: 11px; color: var(--ColorTextMuted); text-transform: uppercase;">Absent</div>
                            </div>
                            <div style="text-align: center; padding: 8px 20px; background: rgba(255,152,0,0.1); border-radius: 8px; border: 1px solid rgba(255,152,0,0.3);">
                                <div style="font-family: var(--FontDisplay); font-size: 18px; font-weight: 700; color: #FF9800;">PKR <?= number_format($TotalFines, 0) ?></div>
                                <div style="font-size: 11px; color: var(--ColorTextMuted); text-transform: uppercase;">Total Fines</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Fine Legend -->
            <div style="display: flex; gap: 10px; flex-wrap: wrap; margin-bottom: 16px;">
                <div class="AlertBox AlertWarning" style="margin: 0; padding: 8px 14px; font-size: 12px;">
                    👗 Uniform Fine: PKR <?= number_format($FineAmounts['UniformFine']) ?>
                </div>
                <div class="AlertBox AlertWarning" style="margin: 0; padding: 8px 14px; font-size: 12px;">
                    🔫 Weapon Fine: PKR <?= number_format($FineAmounts['WeaponFine']) ?>
                </div>
                <div class="AlertBox AlertWarning" style="margin: 0; padding: 8px 14px; font-size: 12px;">
                    ⏰ Late Fine: PKR <?= number_format($FineAmounts['LateFine']) ?>
                </div>
                <div class="AlertBox AlertWarning" style="margin: 0; padding: 8px 14px; font-size: 12px;">
                    ⚖ Conduct Fine: PKR <?= number_format($FineAmounts['ConductFine']) ?>
                </div>
            </div>

            <!-- Attendance Table -->
            <div class="SectionPanel">
                <div class="SectionHeader">
                    <div class="SectionTitle">📊 Attendance Register — <?= date('D, d M Y', strtotime($ViewDate)) ?></div>
                    <span class="Badge BadgeBlue"><?= count($Records) ?> Records</span>
                </div>

                <?php if (empty($Records)): ?>
                    <div class="EmptyState">
                        <div class="EmptyIcon">📋</div>
                        <p>No guards found in the system.</p>
                    </div>
                <?php else: ?>
                <div style="overflow-x: auto;">
                    <table class="DataTable">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Guard Name</th>
                                <th>Shift</th>
                                <th>Present?</th>
                                <th>👗 Uniform</th>
                                <th>🔫 Weapon</th>
                                <th>⏰ Late</th>
                                <th>⚖ Conduct</th>
                                <th>Total Fine</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($Records as $Index => $Row): ?>
                            <tr id="Row_<?= $Row['AttendanceID'] ?>"
                                style="<?= $Row['IsLocked'] ? 'opacity: 0.7;' : '' ?>">

                                <td style="color: var(--ColorTextMuted);"><?= $Index + 1 ?></td>

                                <td><strong><?= htmlspecialchars($Row['FullName']) ?></strong></td>

                                <td>
                                    <?php
                                        $ShiftClass = match($Row['CurrentShift']) {
                                            'Morning'  => 'Badge ShiftMorning',
                                            'Evening'  => 'Badge ShiftEvening',
                                            'Night'    => 'Badge ShiftNight',
                                            default    => 'Badge ShiftOff'
                                        };
                                    ?>
                                    <span class="<?= $ShiftClass ?>"><?= $Row['CurrentShift'] ?></span>
                                </td>

                                <!-- Present Toggle -->
                                <td>
                                    <label class="FineCheckbox">
                                        <input type="checkbox"
                                            id="Present_<?= $Row['AttendanceID'] ?>"
                                            <?= $Row['IsPresent'] ? 'checked' : '' ?>
                                            <?= $Row['IsLocked'] ? 'disabled' : '' ?>
                                            onchange="TogglePresent(<?= $Row['AttendanceID'] ?>, this.checked)">
                                        <span style="color: <?= $Row['IsPresent'] ? '#4CAF50' : '#F44336' ?>;">
                                            <?= $Row['IsPresent'] ? '✅ Yes' : '❌ No' ?>
                                        </span>
                                    </label>
                                </td>

                                <!-- Fine Checkboxes -->
                                <td>
                                    <label class="FineCheckbox">
                                        <input type="checkbox"
                                            class="FineCheck"
                                            id="Uniform_<?= $Row['AttendanceID'] ?>"
                                            data-amount="<?= $FineAmounts['UniformFine'] ?>"
                                            data-aid="<?= $Row['AttendanceID'] ?>"
                                            <?= $Row['UniformFine'] > 0 ? 'checked' : '' ?>
                                            <?= $Row['IsLocked'] ? 'disabled' : '' ?>
                                            onchange="RecalcFine(<?= $Row['AttendanceID'] ?>)">
                                        Apply
                                    </label>
                                </td>

                                <td>
                                    <label class="FineCheckbox">
                                        <input type="checkbox"
                                            class="FineCheck"
                                            id="Weapon_<?= $Row['AttendanceID'] ?>"
                                            data-amount="<?= $FineAmounts['WeaponFine'] ?>"
                                            data-aid="<?= $Row['AttendanceID'] ?>"
                                            <?= $Row['WeaponFine'] > 0 ? 'checked' : '' ?>
                                            <?= $Row['IsLocked'] ? 'disabled' : '' ?>
                                            onchange="RecalcFine(<?= $Row['AttendanceID'] ?>)">
                                        Apply
                                    </label>
                                </td>

                                <td>
                                    <label class="FineCheckbox">
                                        <input type="checkbox"
                                            class="FineCheck"
                                            id="Late_<?= $Row['AttendanceID'] ?>"
                                            data-amount="<?= $FineAmounts['LateFine'] ?>"
                                            data-aid="<?= $Row['AttendanceID'] ?>"
                                            <?= $Row['LateFine'] > 0 ? 'checked' : '' ?>
                                            <?= $Row['IsLocked'] ? 'disabled' : '' ?>
                                            onchange="RecalcFine(<?= $Row['AttendanceID'] ?>)">
                                        Apply
                                    </label>
                                </td>

                                <td>
                                    <label class="FineCheckbox">
                                        <input type="checkbox"
                                            class="FineCheck"
                                            id="Conduct_<?= $Row['AttendanceID'] ?>"
                                            data-amount="<?= $FineAmounts['ConductFine'] ?>"
                                            data-aid="<?= $Row['AttendanceID'] ?>"
                                            <?= $Row['ConductFine'] > 0 ? 'checked' : '' ?>
                                            <?= $Row['IsLocked'] ? 'disabled' : '' ?>
                                            onchange="RecalcFine(<?= $Row['AttendanceID'] ?>)">
                                        Apply
                                    </label>
                                </td>

                                <!-- Total Fine Display -->
                                <td>
                                    <span id="TotalFine_<?= $Row['AttendanceID'] ?>"
                                        style="font-weight: 600; color: <?= $Row['TotalFine'] > 0 ? '#F44336' : '#4CAF50' ?>;">
                                        PKR <?= number_format($Row['TotalFine'], 0) ?>
                                    </span>
                                </td>

                                <!-- Lock Status -->
                                <td>
                                    <?php if ($Row['IsLocked']): ?>
                                        <span class="Badge BadgeMuted">🔒 Locked</span>
                                    <?php else: ?>
                                        <span class="Badge BadgeSuccess">✏️ Open</span>
                                    <?php endif; ?>
                                </td>

                                <!-- Lock Button -->
                                <td>
                                    <?php if (!$Row['IsLocked']): ?>
                                        <button class="Btn BtnPrimary BtnSmall"
                                            onclick="LockRow(<?= $Row['AttendanceID'] ?>)">
                                            🔒 Lock Row
                                        </button>
                                    <?php else: ?>
                                        <span style="color: var(--ColorTextMuted); font-size: 12px;">Done</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
            </div>

        </div>
    </main>
</div>

<script src="js/app.js"></script>
<script src="js/attendance.js"></script>
</body>
</html>
```

### inventory_hub.php
```php
<?php
// =====================================================
// INVENTORY HUB - inventory_hub.php
// Add/manage inventory items, auto-alert for low stock
// =====================================================
require_once 'includes/db_connect.php';
$db = getConnection();

$SuccessMsg = '';
$ErrorMsg   = '';

// ---- Handle: Add New Item ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['FormAction'] ?? '') === 'AddItem') {
    $Name      = trim($_POST['ItemName'] ?? '');
    $Category  = $_POST['Category'] ?? '';
    $Quantity  = (int)($_POST['Quantity'] ?? 0);
    $MinThresh = (int)($_POST['MinThreshold'] ?? 5);
    $AssignTo  = trim($_POST['AssignedTo'] ?? 'Warehouse');

    $AllowedCats = ['Weapons & Gear', 'Office & Logistics', 'Bulk Reserves'];

    if ($Name && in_array($Category, $AllowedCats) && $Quantity >= 0) {
        $stmt = $db->prepare("
            INSERT INTO Inventory (ItemName, Category, Quantity, MinThreshold, AssignedTo)
            VALUES (?, ?, ?, ?, ?)
        ");
        $stmt->execute([$Name, $Category, $Quantity, $MinThresh, $AssignTo]);
        header("Location: inventory_hub.php?added=1");
        exit;
    } else {
        $ErrorMsg = "Please fill in all required fields correctly.";
    }
}

// ---- Handle: Update Quantity ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['FormAction'] ?? '') === 'UpdateQty') {
    $ItemID      = (int)($_POST['ItemID'] ?? 0);
    $NewQuantity = (int)($_POST['NewQuantity'] ?? 0);
    if ($ItemID && $NewQuantity >= 0) {
        $db->prepare("UPDATE Inventory SET Quantity = ? WHERE ItemID = ?")->execute([$NewQuantity, $ItemID]);
        header("Location: inventory_hub.php?updated=1");
        exit;
    }
}

// ---- Handle: Archive Item ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['FormAction'] ?? '') === 'ArchiveItem') {
    $ItemID = (int)($_POST['ItemID'] ?? 0);
    if ($ItemID) {
        $db->prepare("UPDATE Inventory SET IsArchived = 1 WHERE ItemID = ?")->execute([$ItemID]);
        header("Location: inventory_hub.php?archived=1");
        exit;
    }
}

// ---- Fetch all items grouped by category ----
$AllItems = $db->query("SELECT * FROM Inventory WHERE IsArchived = 0 ORDER BY Category, ItemName")->fetchAll();

$Categories = [
    'Weapons & Gear'     => [],
    'Office & Logistics' => [],
    'Bulk Reserves'      => []
];
foreach ($AllItems as $Item) {
    $Categories[$Item['Category']][] = $Item;
}

$LowStockCount = count(array_filter($AllItems, fn($I) => $I['Quantity'] < $I['MinThreshold']));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory | SecureForce</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="AppShell">
    <?php include 'includes/nav.php'; ?>

    <main class="MainContent">

        <div class="TopBar">
            <div class="TopBarTitle">📦 Inventory Management</div>
            <div class="TopBarRight">
                <div class="TopBarDate">
                    <span class="StatusDot"></span>
                    <span id="CurrentDateTime"></span>
                </div>
                <button class="Btn BtnPrimary" onclick="OpenModal('AddItemModal')">
                    ➕ Add New Item
                </button>
            </div>
        </div>

        <div class="PageContent">

            <!-- Alerts -->
            <?php if (isset($_GET['added'])): ?>
                <div class="AlertBox AlertSuccess">✅ New item added to inventory!</div>
            <?php endif; ?>
            <?php if (isset($_GET['updated'])): ?>
                <div class="AlertBox AlertSuccess">✅ Quantity updated!</div>
            <?php endif; ?>
            <?php if ($ErrorMsg): ?>
                <div class="AlertBox AlertDanger">❌ <?= htmlspecialchars($ErrorMsg) ?></div>
            <?php endif; ?>

            <!-- Low Stock Warning Banner -->
            <?php if ($LowStockCount > 0): ?>
            <div class="AlertBox AlertDanger" style="font-size: 14px;">
                ⚠️ <strong><?= $LowStockCount ?> item(s) are below minimum stock threshold!</strong>
                These are highlighted in red below. Please restock immediately.
            </div>
            <?php endif; ?>

            <!-- Stats -->
            <div class="StatsGrid" style="margin-bottom: 24px;">
                <div class="StatCard" style="--CardAccent: #F44336;">
                    <div class="StatCardIcon" style="background: rgba(244,67,54,0.12);">🔫</div>
                    <div class="StatCardBody">
                        <div class="StatValue"><?= count($Categories['Weapons & Gear']) ?></div>
                        <div class="StatLabel">Weapons & Gear</div>
                    </div>
                </div>
                <div class="StatCard" style="--CardAccent: #2196F3;">
                    <div class="StatCardIcon" style="background: rgba(33,150,243,0.12);">🖥️</div>
                    <div class="StatCardBody">
                        <div class="StatValue"><?= count($Categories['Office & Logistics']) ?></div>
                        <div class="StatLabel">Office & Logistics</div>
                    </div>
                </div>
                <div class="StatCard" style="--CardAccent: #4CAF50;">
                    <div class="StatCardIcon" style="background: rgba(76,175,80,0.12);">📦</div>
                    <div class="StatCardBody">
                        <div class="StatValue"><?= count($Categories['Bulk Reserves']) ?></div>
                        <div class="StatLabel">Bulk Reserves</div>
                    </div>
                </div>
                <?php if ($LowStockCount > 0): ?>
                <div class="StatCard" style="--CardAccent: #F44336;">
                    <div class="StatCardIcon" style="background: rgba(244,67,54,0.12);">⚠️</div>
                    <div class="StatCardBody">
                        <div class="StatValue" style="color: #F44336;"><?= $LowStockCount ?></div>
                        <div class="StatLabel">Low Stock Alerts</div>
                    </div>
                </div>
                <?php endif; ?>
            </div>

            <!-- Categories Tables -->
            <?php
            $CategoryIcons = [
                'Weapons & Gear'     => '🔫',
                'Office & Logistics' => '🖥️',
                'Bulk Reserves'      => '📦'
            ];
            $CategoryClasses = [
                'Weapons & Gear'     => 'CatWeapons',
                'Office & Logistics' => 'CatOffice',
                'Bulk Reserves'      => 'CatBulk'
            ];

            foreach ($Categories as $CatName => $Items):
            ?>
            <div class="SectionPanel" style="margin-bottom: 20px;">
                <div class="SectionHeader">
                    <div class="SectionTitle">
                        <?= $CategoryIcons[$CatName] ?> <?= $CatName ?>
                    </div>
                    <span class="Badge <?= $CategoryClasses[$CatName] ?>"><?= count($Items) ?> Items</span>
                </div>

                <?php if (empty($Items)): ?>
                    <div class="EmptyState" style="padding: 30px;">
                        <p>No items in this category. Add one using the button above.</p>
                    </div>
                <?php else: ?>
                <div style="overflow-x: auto;">
                    <table class="DataTable">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Item Name</th>
                                <th>Current Qty</th>
                                <th>Min. Required</th>
                                <th>Assigned To</th>
                                <th>Stock Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($Items as $Idx => $Item): ?>
                            <?php $IsLow = $Item['Quantity'] < $Item['MinThreshold']; ?>
                            <tr style="<?= $IsLow ? 'background: rgba(244,67,54,0.04);' : '' ?>">

                                <td style="color: var(--ColorTextMuted);"><?= $Idx + 1 ?></td>

                                <td>
                                    <strong><?= htmlspecialchars($Item['ItemName']) ?></strong>
                                </td>

                                <td>
                                    <span style="font-family: var(--FontDisplay); font-size: 18px; font-weight: 700;
                                        color: <?= $IsLow ? '#F44336' : '#4CAF50' ?>;">
                                        <?= $Item['Quantity'] ?>
                                    </span>
                                </td>

                                <td style="color: var(--ColorTextSecondary);"><?= $Item['MinThreshold'] ?></td>

                                <td>
                                    <span class="Badge BadgeBlue"><?= htmlspecialchars($Item['AssignedTo']) ?></span>
                                </td>

                                <td>
                                    <?php if ($IsLow): ?>
                                        <div class="CriticalAlert">CRITICAL STOCK DEFICIT</div>
                                    <?php else: ?>
                                        <span class="Badge BadgeSuccess">✅ Sufficient</span>
                                    <?php endif; ?>
                                </td>

                                <td>
                                    <div style="display: flex; gap: 6px; flex-wrap: wrap;">
                                        <button class="Btn BtnSecondary BtnSmall"
                                            onclick="OpenUpdateModal(<?= $Item['ItemID'] ?>, '<?= htmlspecialchars($Item['ItemName']) ?>', <?= $Item['Quantity'] ?>)">
                                            ✏️ Update Qty
                                        </button>
                                        <button class="Btn BtnDanger BtnSmall"
                                            onclick="ArchiveItem(<?= $Item['ItemID'] ?>, '<?= htmlspecialchars($Item['ItemName']) ?>')">
                                            🗃 Remove
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>

        </div>
    </main>
</div>

<!-- =====================================================
     MODAL: Add New Item
     ===================================================== -->
<div class="ModalOverlay" id="AddItemModal">
    <div class="ModalCard">
        <div class="ModalHeader">
            <div class="ModalTitle">➕ Add New Inventory Item</div>
            <button class="ModalClose" onclick="CloseModal('AddItemModal')">✕</button>
        </div>
        <div class="ModalBody">
            <form method="POST" action="inventory_hub.php">
                <input type="hidden" name="FormAction" value="AddItem">

                <div class="FormRow">
                    <div class="FormGroup">
                        <label class="FormLabel">Item Name *</label>
                        <input type="text" name="ItemName" class="FormControl" placeholder="e.g. Pistol 9mm" required>
                    </div>
                    <div class="FormGroup">
                        <label class="FormLabel">Category *</label>
                        <select name="Category" class="FormControl" required>
                            <option value="">Select Category...</option>
                            <option value="Weapons & Gear">🔫 Weapons & Gear</option>
                            <option value="Office & Logistics">🖥️ Office & Logistics</option>
                            <option value="Bulk Reserves">📦 Bulk Reserves</option>
                        </select>
                    </div>
                </div>

                <div class="FormRow">
                    <div class="FormGroup">
                        <label class="FormLabel">Current Quantity *</label>
                        <input type="number" name="Quantity" class="FormControl" min="0" value="0" required>
                    </div>
                    <div class="FormGroup">
                        <label class="FormLabel">Minimum Threshold</label>
                        <input type="number" name="MinThreshold" class="FormControl" min="1" value="5">
                    </div>
                </div>

                <div class="FormGroup" style="margin-bottom: 20px;">
                    <label class="FormLabel">Assigned To / Location</label>
                    <select name="AssignedTo" class="FormControl">
                        <option value="Warehouse">Warehouse</option>
                        <option value="Armory">Armory</option>
                        <option value="Head Office">Head Office</option>
                        <option value="Control Room">Control Room</option>
                        <option value="Medical Room">Medical Room</option>
                    </select>
                </div>

                <div style="display: flex; gap: 10px;">
                    <button type="submit" class="Btn BtnPrimary BtnFull">✅ Add to Inventory</button>
                    <button type="button" class="Btn BtnSecondary" onclick="CloseModal('AddItemModal')">Cancel</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- =====================================================
     MODAL: Update Quantity
     ===================================================== -->
<div class="ModalOverlay" id="UpdateQtyModal">
    <div class="ModalCard" style="max-width: 360px;">
        <div class="ModalHeader">
            <div class="ModalTitle">✏️ Update Quantity</div>
            <button class="ModalClose" onclick="CloseModal('UpdateQtyModal')">✕</button>
        </div>
        <div class="ModalBody">
            <p style="color: var(--ColorTextSecondary); margin-bottom: 16px; font-size: 14px;">
                Item: <strong id="UpdateItemName" style="color: var(--ColorAccentGold);"></strong>
            </p>
            <form method="POST" action="inventory_hub.php">
                <input type="hidden" name="FormAction" value="UpdateQty">
                <input type="hidden" name="ItemID" id="UpdateItemID">

                <div class="FormGroup" style="margin-bottom: 20px;">
                    <label class="FormLabel">New Quantity</label>
                    <input type="number" name="NewQuantity" id="UpdateQtyInput" class="FormControl" min="0" required>
                </div>

                <div style="display: flex; gap: 10px;">
                    <button type="submit" class="Btn BtnPrimary BtnFull">✅ Update</button>
                    <button type="button" class="Btn BtnSecondary" onclick="CloseModal('UpdateQtyModal')">Cancel</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Hidden archive form -->
<form id="ArchiveItemForm" method="POST" action="inventory_hub.php" style="display:none;">
    <input type="hidden" name="FormAction" value="ArchiveItem">
    <input type="hidden" name="ItemID" id="ArchiveItemID">
</form>

<script src="js/app.js"></script>
<script src="js/inventory.js"></script>
</body>
</html>
```

### payroll_hub.php
```php
<?php
// =====================================================
// PAYROLL HUB - payroll_hub.php
// Salary generation, fines deduction, pay records
// =====================================================
require_once 'includes/db_connect.php';
$db = getConnection();

// ---- Default to current month ----
$SelectedMonth = $_GET['month'] ?? date('Y-m');

// ---- Fetch payroll records for selected month ----
$PayrollStmt = $db->prepare("
    SELECT p.*, g.FullName
    FROM Payroll p
    JOIN Guards g ON p.GuardID = g.GuardID
    WHERE p.PayMonth = ?
    ORDER BY g.FullName ASC
");
$PayrollStmt->execute([$SelectedMonth]);
$PayrollRecords = $PayrollStmt->fetchAll();

// ---- Stats ----
$TotalNet  = array_sum(array_column($PayrollRecords, 'NetSalary'));
$PaidCount = count(array_filter($PayrollRecords, fn($R) => $R['IsPaid']));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payroll Hub | SecureForce</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        .PayrollGrid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 16px;
        }
    </style>
</head>
<body>

<div class="AppShell">
    <?php include 'includes/nav.php'; ?>

    <main class="MainContent">

        <div class="TopBar">
            <div class="TopBarTitle">💰 Payroll & Salary Hub</div>
            <div class="TopBarRight">
                <div class="TopBarDate">
                    <span class="StatusDot"></span>
                    <span id="CurrentDateTime"></span>
                </div>
            </div>
        </div>

        <div class="PageContent">

            <!-- Month Selector + Generate Button -->
            <div class="SectionPanel" style="margin-bottom: 20px;">
                <div class="SectionBody" style="padding: 16px 22px;">
                    <div style="display: flex; align-items: center; gap: 14px; flex-wrap: wrap;">
                        <div style="display: flex; align-items: center; gap: 10px;">
                            <label class="FormLabel" style="margin: 0; white-space: nowrap;">📅 Select Month:</label>
                            <input type="month" id="MonthPicker" class="FormControl" style="width: auto;"
                                value="<?= htmlspecialchars($SelectedMonth) ?>"
                                onchange="window.location.href='payroll_hub.php?month=' + this.value">
                        </div>
                        <button class="Btn BtnPrimary" onclick="GeneratePayroll()">
                            ⚡ Generate Payroll for <?= date('F Y', strtotime($SelectedMonth . '-01')) ?>
                        </button>
                    </div>
                </div>
            </div>

            <!-- Summary Stats -->
            <?php if (!empty($PayrollRecords)): ?>
            <div class="StatsGrid" style="margin-bottom: 20px;">

                <div class="StatCard" style="--CardAccent: #FF9800;">
                    <div class="StatCardIcon" style="background: rgba(255,152,0,0.12);">👮</div>
                    <div class="StatCardBody">
                        <div class="StatValue"><?= count($PayrollRecords) ?></div>
                        <div class="StatLabel">Guards in Payroll</div>
                    </div>
                </div>

                <div class="StatCard" style="--CardAccent: #4CAF50;">
                    <div class="StatCardIcon" style="background: rgba(76,175,80,0.12);">✅</div>
                    <div class="StatCardBody">
                        <div class="StatValue"><?= $PaidCount ?></div>
                        <div class="StatLabel">Paid</div>
                    </div>
                </div>

                <div class="StatCard" style="--CardAccent: #5B7F95;">
                    <div class="StatCardIcon" style="background: rgba(91,127,149,0.12);">💵</div>
                    <div class="StatCardBody">
                        <div class="StatValue" style="font-size: 18px;">PKR <?= number_format($TotalNet, 0) ?></div>
                        <div class="StatLabel">Total Net Payout</div>
                    </div>
                </div>

            </div>
            <?php endif; ?>

            <!-- Payroll Cards -->
            <?php if (empty($PayrollRecords)): ?>
                <div class="SectionPanel">
                    <div class="EmptyState">
                        <div class="EmptyIcon">💰</div>
                        <p>No payroll generated for <?= date('F Y', strtotime($SelectedMonth . '-01')) ?>.</p>
                        <p style="margin-top: 8px; font-size: 13px;">Click "Generate Payroll" above to create salary records.</p>
                    </div>
                </div>
            <?php else: ?>

                <div class="SectionPanel">
                    <div class="SectionHeader">
                        <div class="SectionTitle">📄 Salary Records — <?= date('F Y', strtotime($SelectedMonth . '-01')) ?></div>
                    </div>
                    <div class="SectionBody">
                        <div class="PayrollGrid">
                            <?php foreach ($PayrollRecords as $P): ?>
                            <div class="PayrollCard" id="PayCard_<?= $P['PayrollID'] ?>">

                                <div class="PayrollCardName">
                                    <?= htmlspecialchars($P['FullName']) ?>
                                    <?php if ($P['IsPaid']): ?>
                                        <span class="Badge BadgeSuccess" style="font-size: 10px; vertical-align: middle; margin-left: 6px;">PAID</span>
                                    <?php endif; ?>
                                </div>

                                <div class="PayrollRow">
                                    <span>Base Salary</span>
                                    <span>PKR <?= number_format($P['BaseSalary'], 0) ?></span>
                                </div>

                                <div class="PayrollRow">
                                    <span>Days Absent</span>
                                    <span class="PayrollDeduct"><?= $P['TotalAbsents'] ?> days</span>
                                </div>

                                <div class="PayrollRow">
                                    <span>Absent Deduction</span>
                                    <span class="PayrollDeduct">- PKR <?= number_format($P['AbsentDeduction'], 0) ?></span>
                                </div>

                                <div class="PayrollRow">
                                    <span>Fine Deductions</span>
                                    <span class="PayrollDeduct">- PKR <?= number_format($P['TotalFines'], 0) ?></span>
                                </div>

                                <div class="PayrollRow" style="border-top: 2px solid var(--ColorBorder); margin-top: 8px; padding-top: 8px;">
                                    <span style="font-weight: 600;">Net Salary</span>
                                    <span class="PayrollNet">PKR <?= number_format($P['NetSalary'], 0) ?></span>
                                </div>

                                <?php if (!$P['IsPaid']): ?>
                                <div style="margin-top: 14px;">
                                    <button class="Btn BtnSuccess BtnFull BtnSmall"
                                        onclick="MarkAsPaid(<?= $P['PayrollID'] ?>)">
                                        ✅ Mark as Paid
                                    </button>
                                </div>
                                <?php endif; ?>

                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>

            <?php endif; ?>

        </div>
    </main>
</div>

<script src="js/app.js"></script>
<script src="js/payroll.js"></script>
<script>
    // Pass selected month to JS
    const SelectedPayMonth = '<?= htmlspecialchars($SelectedMonth) ?>';
</script>
</body>
</html>
```

### database.sql
```sql
-- =====================================================
-- SECURITY FIRM MANAGEMENT SYSTEM - DATABASE SETUP
-- Run this entire file in phpMyAdmin SQL tab
-- =====================================================

CREATE DATABASE IF NOT EXISTS security_firm;
USE security_firm;

-- =====================================================
-- TABLE 1: Guards (Security Personnel)
-- =====================================================
CREATE TABLE Guards (
    GuardID       INT AUTO_INCREMENT PRIMARY KEY,
    FullName      VARCHAR(100) NOT NULL,
    CNIC          VARCHAR(15) NOT NULL UNIQUE,
    Phone         VARCHAR(20),
    EmergencyPhone VARCHAR(20),
    BloodGroup    VARCHAR(5),
    Address       TEXT,
    JoiningDate   DATE NOT NULL,
    CurrentShift  ENUM('Morning','Evening','Night','Off Duty') DEFAULT 'Off Duty',
    Status        ENUM('Active','Inactive') DEFAULT 'Active',
    IsArchived    TINYINT(1) DEFAULT 0,
    CreatedAt     TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =====================================================
-- TABLE 2: Attendance Records
-- =====================================================
CREATE TABLE Attendance (
    AttendanceID      INT AUTO_INCREMENT PRIMARY KEY,
    GuardID           INT NOT NULL,
    AttendanceDate    DATE NOT NULL,
    IsPresent         TINYINT(1) DEFAULT 1,
    UniformFine       DECIMAL(10,2) DEFAULT 0.00,
    WeaponFine        DECIMAL(10,2) DEFAULT 0.00,
    LateFine          DECIMAL(10,2) DEFAULT 0.00,
    ConductFine       DECIMAL(10,2) DEFAULT 0.00,
    TotalFine         DECIMAL(10,2) DEFAULT 0.00,
    IsLocked          TINYINT(1) DEFAULT 0,
    Remarks           TEXT,
    CreatedAt         TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (GuardID) REFERENCES Guards(GuardID)
);

-- =====================================================
-- TABLE 3: Payroll
-- =====================================================
CREATE TABLE Payroll (
    PayrollID     INT AUTO_INCREMENT PRIMARY KEY,
    GuardID       INT NOT NULL,
    PayMonth      VARCHAR(7) NOT NULL,
    BaseSalary    DECIMAL(10,2) DEFAULT 45000.00,
    TotalFines    DECIMAL(10,2) DEFAULT 0.00,
    TotalAbsents  INT DEFAULT 0,
    AbsentDeduction DECIMAL(10,2) DEFAULT 0.00,
    NetSalary     DECIMAL(10,2) DEFAULT 0.00,
    IsPaid        TINYINT(1) DEFAULT 0,
    GeneratedAt   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (GuardID) REFERENCES Guards(GuardID)
);

-- =====================================================
-- TABLE 4: Inventory
-- =====================================================
CREATE TABLE Inventory (
    ItemID        INT AUTO_INCREMENT PRIMARY KEY,
    ItemName      VARCHAR(150) NOT NULL,
    Category      ENUM('Weapons & Gear','Office & Logistics','Bulk Reserves') NOT NULL,
    Quantity      INT DEFAULT 0,
    MinThreshold  INT DEFAULT 5,
    AssignedTo    VARCHAR(100) DEFAULT 'Warehouse',
    IsArchived    TINYINT(1) DEFAULT 0,
    CreatedAt     TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =====================================================
-- SAMPLE DATA - Guards
-- =====================================================
INSERT INTO Guards (FullName, CNIC, Phone, EmergencyPhone, BloodGroup, Address, JoiningDate, CurrentShift, Status) VALUES
('Ali Hassan',       '35201-1234567-1', '0300-1111111', '0301-1111112', 'B+',  'Rawalpindi, Punjab',   '2023-01-15', 'Morning',   'Active'),
('Muhammad Bilal',   '35202-2345678-2', '0311-2222222', '0312-2222223', 'O+',  'Islamabad, Pakistan',  '2023-03-20', 'Evening',   'Active'),
('Usman Tariq',      '35203-3456789-3', '0321-3333333', '0322-3333334', 'A+',  'Lahore, Punjab',       '2023-06-10', 'Night',     'Active'),
('Kamran Malik',     '35204-4567890-4', '0333-4444444', '0334-4444445', 'AB+', 'Rawalpindi, Punjab',   '2023-08-01', 'Morning',   'Active'),
('Zubair Ahmed',     '35205-5678901-5', '0345-5555555', '0346-5555556', 'B-',  'Peshawar, KPK',        '2024-01-05', 'Off Duty',  'Active'),
('Tariq Mehmood',    '35206-6789012-6', '0300-6666666', '0301-6666667', 'O-',  'Faisalabad, Punjab',   '2024-02-14', 'Evening',   'Active');

-- =====================================================
-- SAMPLE DATA - Attendance (Today)
-- =====================================================
INSERT INTO Attendance (GuardID, AttendanceDate, IsPresent, UniformFine, WeaponFine, LateFine, ConductFine, TotalFine, IsLocked) VALUES
(1, CURDATE(), 1, 0.00,    0.00,    0.00,    0.00,    0.00,    0),
(2, CURDATE(), 1, 500.00,  0.00,    0.00,    0.00,    500.00,  0),
(3, CURDATE(), 1, 0.00,    1000.00, 0.00,    0.00,    1000.00, 0),
(4, CURDATE(), 0, 0.00,    0.00,    0.00,    0.00,    0.00,    0),
(5, CURDATE(), 1, 0.00,    0.00,    300.00,  0.00,    300.00,  0),
(6, CURDATE(), 1, 0.00,    0.00,    0.00,    500.00,  500.00,  0);

-- =====================================================
-- SAMPLE DATA - Inventory
-- =====================================================
INSERT INTO Inventory (ItemName, Category, Quantity, MinThreshold, AssignedTo) VALUES
('Pistol 9mm',          'Weapons & Gear',    12,  5,  'Armory'),
('Guard Uniform Set',   'Weapons & Gear',    30,  10, 'Warehouse'),
('Baton / Lathi',       'Weapons & Gear',    20,  8,  'Armory'),
('Walkie Talkie',       'Weapons & Gear',    8,   5,  'Control Room'),
('Bulletproof Vest',    'Weapons & Gear',    3,   5,  'Armory'),
('Office Laptop',       'Office & Logistics',5,   2,  'Head Office'),
('CCTV Camera',         'Office & Logistics',15,  4,  'Warehouse'),
('Attendance Register', 'Office & Logistics',10,  3,  'Head Office'),
('Printer Paper Ream',  'Bulk Reserves',     2,   10, 'Warehouse'),
('First Aid Kit',       'Bulk Reserves',     6,   5,  'Medical Room'),
('Torch / Flashlight',  'Bulk Reserves',     25,  10, 'Warehouse');

-- =====================================================
-- DONE! Your database is ready.
-- =====================================================
```

## 2. API & Data

### api/api_router.php
```php
<?php
// =====================================================
// API ROUTER - api/api_router.php
// All JavaScript fetch() calls come here
// Action parameter tells which function to run
// =====================================================
require_once '../includes/db_connect.php';
header('Content-Type: application/json');

$db     = getConnection();
$Action = $_GET['Action'] ?? $_POST['Action'] ?? '';

// =====================================================
// ROUTE TO CORRECT ACTION
// =====================================================
switch ($Action) {

    // ---- Get single guard profile ----
    case 'GetGuardProfile':
        $GuardID = (int)($_GET['GuardID'] ?? 0);
        if (!$GuardID) {
            echo json_encode(['success' => false, 'message' => 'Invalid Guard ID']);
            break;
        }
        $stmt = $db->prepare("SELECT * FROM Guards WHERE GuardID = ? AND IsArchived = 0");
        $stmt->execute([$GuardID]);
        $Guard = $stmt->fetch();

        if ($Guard) {
            echo json_encode(['success' => true, 'guard' => $Guard]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Guard not found']);
        }
        break;

    // ---- Lock attendance row and calculate fines ----
    case 'LockAttendance':
        $AttendanceID = (int)($_POST['AttendanceID'] ?? 0);
        $UniformFine  = (float)($_POST['UniformFine'] ?? 0);
        $WeaponFine   = (float)($_POST['WeaponFine'] ?? 0);
        $LateFine     = (float)($_POST['LateFine'] ?? 0);
        $ConductFine  = (float)($_POST['ConductFine'] ?? 0);
        $IsPresent    = (int)($_POST['IsPresent'] ?? 1);

        $TotalFine = $UniformFine + $WeaponFine + $LateFine + $ConductFine;

        if (!$AttendanceID) {
            echo json_encode(['success' => false, 'message' => 'Invalid Attendance ID']);
            break;
        }

        try {
            $stmt = $db->prepare("
                UPDATE Attendance
                SET UniformFine = ?, WeaponFine = ?, LateFine = ?, ConductFine = ?,
                    TotalFine = ?, IsPresent = ?, IsLocked = 1
                WHERE AttendanceID = ?
            ");
            $stmt->execute([$UniformFine, $WeaponFine, $LateFine, $ConductFine, $TotalFine, $IsPresent, $AttendanceID]);
            echo json_encode([
                'success'    => true,
                'message'    => 'Row locked successfully!',
                'TotalFine'  => number_format($TotalFine, 2)
            ]);
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
        }
        break;

    // ---- Mark attendance record as absent ----
    case 'TogglePresent':
        $AttendanceID = (int)($_POST['AttendanceID'] ?? 0);
        $IsPresent    = (int)($_POST['IsPresent'] ?? 1);

        if (!$AttendanceID) {
            echo json_encode(['success' => false, 'message' => 'Invalid ID']);
            break;
        }

        $stmt = $db->prepare("UPDATE Attendance SET IsPresent = ? WHERE AttendanceID = ? AND IsLocked = 0");
        $stmt->execute([$IsPresent, $AttendanceID]);
        echo json_encode(['success' => true]);
        break;

    // ---- Generate payroll for a specific month ----
    case 'GeneratePayroll':
        $PayMonth = $_POST['PayMonth'] ?? '';
        if (!$PayMonth) {
            echo json_encode(['success' => false, 'message' => 'Select a month first']);
            break;
        }

        try {
            $db->beginTransaction();

            // Get all active guards
            $Guards = $db->query("SELECT GuardID, FullName FROM Guards WHERE IsArchived = 0 AND Status = 'Active'")->fetchAll();

            $DailyRate = 45000 / 30; // PKR 45,000 / 30 days

            foreach ($Guards as $Guard) {
                $GID = $Guard['GuardID'];

                // Check if payroll already exists for this month
                $Exists = $db->prepare("SELECT PayrollID FROM Payroll WHERE GuardID = ? AND PayMonth = ?");
                $Exists->execute([$GID, $PayMonth]);
                if ($Exists->fetch()) continue;

                // Count absents for the month
                $AbsentStmt = $db->prepare("
                    SELECT COUNT(*) FROM Attendance
                    WHERE GuardID = ? AND IsPresent = 0
                    AND DATE_FORMAT(AttendanceDate, '%Y-%m') = ?
                ");
                $AbsentStmt->execute([$GID, $PayMonth]);
                $TotalAbsents = (int)$AbsentStmt->fetchColumn();

                // Sum all fines for the month
                $FineStmt = $db->prepare("
                    SELECT COALESCE(SUM(TotalFine), 0) FROM Attendance
                    WHERE GuardID = ? AND IsLocked = 1
                    AND DATE_FORMAT(AttendanceDate, '%Y-%m') = ?
                ");
                $FineStmt->execute([$GID, $PayMonth]);
                $TotalFines = (float)$FineStmt->fetchColumn();

                $BaseSalary      = 45000.00;
                $AbsentDeduction = round($TotalAbsents * $DailyRate, 2);
                $NetSalary       = $BaseSalary - $TotalFines - $AbsentDeduction;
                if ($NetSalary < 0) $NetSalary = 0;

                $InsertStmt = $db->prepare("
                    INSERT INTO Payroll (GuardID, PayMonth, BaseSalary, TotalFines, TotalAbsents, AbsentDeduction, NetSalary)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                ");
                $InsertStmt->execute([$GID, $PayMonth, $BaseSalary, $TotalFines, $TotalAbsents, $AbsentDeduction, $NetSalary]);
            }

            $db->commit();
            echo json_encode(['success' => true, 'message' => 'Payroll generated for ' . $PayMonth]);

        } catch (PDOException $e) {
            $db->rollBack();
            echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
        }
        break;

    // ---- Mark payroll as paid ----
    case 'MarkPaid':
        $PayrollID = (int)($_POST['PayrollID'] ?? 0);
        if (!$PayrollID) {
            echo json_encode(['success' => false, 'message' => 'Invalid ID']);
            break;
        }
        $db->prepare("UPDATE Payroll SET IsPaid = 1 WHERE PayrollID = ?")->execute([$PayrollID]);
        echo json_encode(['success' => true, 'message' => 'Marked as paid!']);
        break;

    // ---- Default: unknown action ----
    default:
        echo json_encode(['success' => false, 'message' => 'Unknown action: ' . htmlspecialchars($Action)]);
        break;
}
?>
```

## 3. Styles & Components

### css/style.css
```css
/* =====================================================
   SECURITY FIRM MANAGEMENT SYSTEM - MAIN STYLESHEET
   style.css
   ===================================================== */

@import url('https://fonts.googleapis.com/css2?family=Rajdhani:wght@400;500;600;700&family=Inter:wght@300;400;500;600&display=swap');

/* ---- CSS Variables (Design Tokens) ---- */
:root {
    --ColorBackground:    #0B0F19;
    --ColorSurface:       #131929;
    --ColorPanel:         #1A2235;
    --ColorBorder:        #243050;
    --ColorAccentGold:    #FF9800;
    --ColorAccentGoldDim: #C97900;
    --ColorAccentBlue:    #5B7F95;
    --ColorAccentBlueDim: #3D5A6D;
    --ColorSuccess:       #4CAF50;
    --ColorDanger:        #F44336;
    --ColorWarning:       #FF9800;
    --ColorTextPrimary:   #E8EDF5;
    --ColorTextSecondary: #8A9BB5;
    --ColorTextMuted:     #4A5C7A;
    --FontDisplay:        'Rajdhani', sans-serif;
    --FontBody:           'Inter', sans-serif;
    --RadiusCard:         10px;
    --RadiusSmall:        6px;
    --ShadowCard:         0 4px 24px rgba(0,0,0,0.4);
    --TransitionFast:     0.2s ease;
    --TransitionMedium:   0.35s ease;
    --SidebarWidth:       260px;
}

/* ---- Reset & Base ---- */
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

html, body {
    height: 100%;
    font-family: var(--FontBody);
    background: var(--ColorBackground);
    color: var(--ColorTextPrimary);
    font-size: 14px;
    line-height: 1.6;
}

a { text-decoration: none; color: inherit; }
button { cursor: pointer; border: none; outline: none; font-family: var(--FontBody); }
input, select, textarea { font-family: var(--FontBody); outline: none; }
table { border-collapse: collapse; width: 100%; }

/* =====================================================
   LAYOUT - Sidebar + Content
   ===================================================== */
.AppShell {
    display: flex;
    height: 100vh;
    overflow: hidden;
}

/* ---- Left Sidebar (Fixed) ---- */
.SideNav {
    width: var(--SidebarWidth);
    background: var(--ColorSurface);
    border-right: 1px solid var(--ColorBorder);
    display: flex;
    flex-direction: column;
    flex-shrink: 0;
    position: fixed;
    top: 0;
    left: 0;
    height: 100vh;
    z-index: 100;
    transition: var(--TransitionMedium);
}

.SideNavBrand {
    padding: 24px 20px 20px;
    border-bottom: 1px solid var(--ColorBorder);
}

.SideNavBrand .BrandLogo {
    width: 42px;
    height: 42px;
    background: linear-gradient(135deg, var(--ColorAccentGold), var(--ColorAccentGoldDim));
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-family: var(--FontDisplay);
    font-size: 20px;
    font-weight: 700;
    color: #0B0F19;
    margin-bottom: 12px;
    box-shadow: 0 4px 12px rgba(255,152,0,0.3);
}

.SideNavBrand .BrandTitle {
    font-family: var(--FontDisplay);
    font-size: 16px;
    font-weight: 700;
    color: var(--ColorTextPrimary);
    letter-spacing: 0.5px;
}

.SideNavBrand .BrandSubtitle {
    font-size: 11px;
    color: var(--ColorTextSecondary);
    letter-spacing: 1px;
    text-transform: uppercase;
    margin-top: 2px;
}

.SideNavMenu {
    flex: 1;
    overflow-y: auto;
    padding: 16px 0;
}

.SideNavSection {
    padding: 0 12px;
    margin-bottom: 8px;
}

.SideNavSectionLabel {
    font-size: 10px;
    font-weight: 600;
    letter-spacing: 1.5px;
    text-transform: uppercase;
    color: var(--ColorTextMuted);
    padding: 12px 8px 6px;
}

.SideNavLink {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 10px 12px;
    border-radius: var(--RadiusSmall);
    color: var(--ColorTextSecondary);
    font-size: 13.5px;
    font-weight: 500;
    transition: var(--TransitionFast);
    margin-bottom: 2px;
    position: relative;
}

.SideNavLink:hover {
    background: var(--ColorPanel);
    color: var(--ColorTextPrimary);
}

.SideNavLink.Active {
    background: rgba(255, 152, 0, 0.12);
    color: var(--ColorAccentGold);
    border-left: 3px solid var(--ColorAccentGold);
}

.SideNavLink .NavIcon {
    font-size: 18px;
    width: 22px;
    text-align: center;
}

.SideNavFooter {
    padding: 16px 20px;
    border-top: 1px solid var(--ColorBorder);
    font-size: 11px;
    color: var(--ColorTextMuted);
    text-align: center;
}

/* ---- Right Content Area (Scrollable) ---- */
.MainContent {
    margin-left: var(--SidebarWidth);
    flex: 1;
    overflow-y: auto;
    height: 100vh;
    background: var(--ColorBackground);
}

/* ---- Top Header Bar ---- */
.TopBar {
    background: var(--ColorSurface);
    border-bottom: 1px solid var(--ColorBorder);
    padding: 0 28px;
    height: 64px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    position: sticky;
    top: 0;
    z-index: 50;
}

.TopBarTitle {
    font-family: var(--FontDisplay);
    font-size: 20px;
    font-weight: 600;
    color: var(--ColorTextPrimary);
    letter-spacing: 0.5px;
}

.TopBarRight {
    display: flex;
    align-items: center;
    gap: 16px;
}

.TopBarDate {
    font-size: 12px;
    color: var(--ColorTextSecondary);
    background: var(--ColorPanel);
    padding: 6px 14px;
    border-radius: 20px;
    border: 1px solid var(--ColorBorder);
}

.StatusDot {
    display: inline-block;
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: var(--ColorSuccess);
    margin-right: 6px;
    animation: PulseDot 2s infinite;
}

@keyframes PulseDot {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.3; }
}

/* ---- Page Content Wrapper ---- */
.PageContent {
    padding: 28px;
}

/* =====================================================
   REUSABLE COMPONENTS
   ===================================================== */

/* ---- Stats Widget Cards ---- */
.StatsGrid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 18px;
    margin-bottom: 28px;
}

.StatCard {
    background: var(--ColorPanel);
    border: 1px solid var(--ColorBorder);
    border-radius: var(--RadiusCard);
    padding: 20px 22px;
    display: flex;
    align-items: center;
    gap: 16px;
    transition: var(--TransitionFast);
    position: relative;
    overflow: hidden;
}

.StatCard::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 3px;
    background: var(--CardAccent, var(--ColorAccentBlue));
}

.StatCard:hover {
    border-color: var(--ColorAccentBlueDim);
    transform: translateY(-2px);
    box-shadow: var(--ShadowCard);
}

.StatCardIcon {
    width: 48px;
    height: 48px;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 22px;
    background: rgba(91, 127, 149, 0.15);
    flex-shrink: 0;
}

.StatCardBody .StatValue {
    font-family: var(--FontDisplay);
    font-size: 28px;
    font-weight: 700;
    color: var(--ColorTextPrimary);
    line-height: 1;
}

.StatCardBody .StatLabel {
    font-size: 12px;
    color: var(--ColorTextSecondary);
    margin-top: 4px;
    text-transform: uppercase;
    letter-spacing: 0.8px;
}

/* ---- Section Panel ---- */
.SectionPanel {
    background: var(--ColorPanel);
    border: 1px solid var(--ColorBorder);
    border-radius: var(--RadiusCard);
    margin-bottom: 24px;
    overflow: hidden;
}

.SectionHeader {
    padding: 18px 22px;
    border-bottom: 1px solid var(--ColorBorder);
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.SectionTitle {
    font-family: var(--FontDisplay);
    font-size: 17px;
    font-weight: 600;
    color: var(--ColorTextPrimary);
}

.SectionBody {
    padding: 22px;
}

/* ---- Data Table ---- */
.DataTable {
    width: 100%;
}

.DataTable thead tr {
    background: var(--ColorSurface);
}

.DataTable th {
    padding: 12px 14px;
    font-size: 11px;
    font-weight: 600;
    letter-spacing: 1px;
    text-transform: uppercase;
    color: var(--ColorTextMuted);
    text-align: left;
    border-bottom: 1px solid var(--ColorBorder);
}

.DataTable td {
    padding: 13px 14px;
    border-bottom: 1px solid rgba(36, 48, 80, 0.6);
    font-size: 13.5px;
    color: var(--ColorTextPrimary);
    vertical-align: middle;
}

.DataTable tbody tr:last-child td {
    border-bottom: none;
}

.DataTable tbody tr:hover {
    background: rgba(91, 127, 149, 0.05);
}

/* ---- Badges / Pills ---- */
.Badge {
    display: inline-flex;
    align-items: center;
    padding: 3px 10px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 600;
    letter-spacing: 0.5px;
}

.BadgeSuccess  { background: rgba(76, 175, 80, 0.15);  color: #4CAF50; }
.BadgeDanger   { background: rgba(244, 67, 54, 0.15);  color: #F44336; }
.BadgeWarning  { background: rgba(255, 152, 0, 0.15);  color: #FF9800; }
.BadgeBlue     { background: rgba(91, 127, 149, 0.2);  color: #8BB8D0; }
.BadgeMuted    { background: rgba(74, 92, 122, 0.2);   color: var(--ColorTextSecondary); }

/* ---- Buttons ---- */
.Btn {
    display: inline-flex;
    align-items: center;
    gap: 7px;
    padding: 8px 18px;
    border-radius: var(--RadiusSmall);
    font-size: 13px;
    font-weight: 600;
    transition: var(--TransitionFast);
    letter-spacing: 0.3px;
}

.BtnPrimary {
    background: var(--ColorAccentGold);
    color: #0B0F19;
}
.BtnPrimary:hover {
    background: #FFB74D;
    box-shadow: 0 4px 12px rgba(255,152,0,0.3);
    transform: translateY(-1px);
}

.BtnSecondary {
    background: var(--ColorPanel);
    color: var(--ColorTextPrimary);
    border: 1px solid var(--ColorBorder);
}
.BtnSecondary:hover {
    border-color: var(--ColorAccentBlue);
    color: var(--ColorAccentBlue);
}

.BtnDanger {
    background: rgba(244,67,54,0.15);
    color: #F44336;
    border: 1px solid rgba(244,67,54,0.3);
}
.BtnDanger:hover { background: rgba(244,67,54,0.25); }

.BtnSuccess {
    background: rgba(76,175,80,0.15);
    color: #4CAF50;
    border: 1px solid rgba(76,175,80,0.3);
}
.BtnSuccess:hover { background: rgba(76,175,80,0.25); }

.BtnSmall { padding: 5px 12px; font-size: 12px; }
.BtnFull  { width: 100%; justify-content: center; }

/* ---- Form Inputs ---- */
.FormRow {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 16px;
    margin-bottom: 16px;
}

.FormGroup {
    display: flex;
    flex-direction: column;
    gap: 6px;
}

.FormLabel {
    font-size: 12px;
    font-weight: 600;
    letter-spacing: 0.5px;
    text-transform: uppercase;
    color: var(--ColorTextSecondary);
}

.FormControl {
    background: var(--ColorSurface);
    border: 1px solid var(--ColorBorder);
    border-radius: var(--RadiusSmall);
    color: var(--ColorTextPrimary);
    padding: 10px 14px;
    font-size: 13.5px;
    transition: var(--TransitionFast);
    width: 100%;
}

.FormControl:focus {
    border-color: var(--ColorAccentBlue);
    box-shadow: 0 0 0 3px rgba(91, 127, 149, 0.15);
}

.FormControl::placeholder { color: var(--ColorTextMuted); }

select.FormControl option {
    background: var(--ColorSurface);
    color: var(--ColorTextPrimary);
}

/* ---- Modal Popup ---- */
.ModalOverlay {
    position: fixed;
    inset: 0;
    background: rgba(11, 15, 25, 0.85);
    backdrop-filter: blur(4px);
    z-index: 1000;
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0;
    pointer-events: none;
    transition: var(--TransitionMedium);
}

.ModalOverlay.Open {
    opacity: 1;
    pointer-events: all;
}

.ModalCard {
    background: var(--ColorPanel);
    border: 1px solid var(--ColorBorder);
    border-radius: 14px;
    width: 90%;
    max-width: 560px;
    max-height: 90vh;
    overflow-y: auto;
    box-shadow: 0 20px 60px rgba(0,0,0,0.6);
    transform: translateY(20px) scale(0.97);
    transition: var(--TransitionMedium);
}

.ModalOverlay.Open .ModalCard {
    transform: translateY(0) scale(1);
}

.ModalHeader {
    padding: 20px 24px;
    border-bottom: 1px solid var(--ColorBorder);
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.ModalTitle {
    font-family: var(--FontDisplay);
    font-size: 18px;
    font-weight: 600;
}

.ModalClose {
    width: 32px;
    height: 32px;
    border-radius: 8px;
    background: var(--ColorSurface);
    border: 1px solid var(--ColorBorder);
    color: var(--ColorTextSecondary);
    font-size: 18px;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: var(--TransitionFast);
}
.ModalClose:hover { color: var(--ColorDanger); border-color: var(--ColorDanger); }

.ModalBody { padding: 24px; }

/* ---- Alert / Notification ---- */
.AlertBox {
    padding: 12px 16px;
    border-radius: var(--RadiusSmall);
    font-size: 13.5px;
    margin-bottom: 16px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.AlertSuccess { background: rgba(76,175,80,0.1);  border: 1px solid rgba(76,175,80,0.3);  color: #81C784; }
.AlertDanger  { background: rgba(244,67,54,0.1);  border: 1px solid rgba(244,67,54,0.3);  color: #EF9A9A; }
.AlertWarning { background: rgba(255,152,0,0.1);  border: 1px solid rgba(255,152,0,0.3);  color: #FFCC80; }

/* ---- Toast Notification ---- */
.ToastContainer {
    position: fixed;
    top: 20px;
    right: 20px;
    z-index: 9999;
    display: flex;
    flex-direction: column;
    gap: 10px;
}

.Toast {
    background: var(--ColorPanel);
    border: 1px solid var(--ColorBorder);
    border-radius: var(--RadiusCard);
    padding: 14px 18px;
    min-width: 280px;
    box-shadow: var(--ShadowCard);
    display: flex;
    align-items: center;
    gap: 12px;
    font-size: 13.5px;
    animation: SlideInRight 0.3s ease;
    border-left: 4px solid var(--ColorAccentBlue);
}

.Toast.ToastSuccess { border-left-color: var(--ColorSuccess); }
.Toast.ToastDanger  { border-left-color: var(--ColorDanger); }

@keyframes SlideInRight {
    from { transform: translateX(100%); opacity: 0; }
    to   { transform: translateX(0);    opacity: 1; }
}

/* ---- Guard Profile Card (inside modal) ---- */
.ProfileCardHeader {
    display: flex;
    align-items: center;
    gap: 18px;
    margin-bottom: 22px;
    padding-bottom: 18px;
    border-bottom: 1px solid var(--ColorBorder);
}

.ProfileAvatar {
    width: 62px;
    height: 62px;
    background: linear-gradient(135deg, var(--ColorAccentBlue), var(--ColorAccentBlueDim));
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-family: var(--FontDisplay);
    font-size: 24px;
    font-weight: 700;
    color: white;
    flex-shrink: 0;
}

.ProfileInfoGrid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 14px;
}

.ProfileInfoItem .InfoKey {
    font-size: 11px;
    font-weight: 600;
    letter-spacing: 0.8px;
    text-transform: uppercase;
    color: var(--ColorTextMuted);
    margin-bottom: 3px;
}

.ProfileInfoItem .InfoValue {
    font-size: 14px;
    color: var(--ColorTextPrimary);
    font-weight: 500;
}

/* ---- Critical Stock Alert ---- */
.CriticalAlert {
    display: flex;
    align-items: center;
    gap: 8px;
    background: rgba(244,67,54,0.08);
    border: 1px solid rgba(244,67,54,0.3);
    border-radius: var(--RadiusSmall);
    padding: 5px 12px;
    font-size: 12px;
    font-weight: 600;
    color: #F44336;
    letter-spacing: 0.5px;
}

.CriticalAlert::before {
    content: '⚠';
    font-size: 13px;
}

/* ---- Attendance Checkboxes ---- */
.FineCheckbox {
    display: flex;
    align-items: center;
    gap: 6px;
    cursor: pointer;
    font-size: 12px;
    color: var(--ColorTextSecondary);
}

.FineCheckbox input[type="checkbox"] {
    accent-color: var(--ColorAccentGold);
    width: 15px;
    height: 15px;
    cursor: pointer;
}

/* ---- Shift Badges ---- */
.ShiftMorning { color: #FFB74D; background: rgba(255,183,77,0.12); }
.ShiftEvening { color: #7986CB; background: rgba(121,134,203,0.12); }
.ShiftNight   { color: #4FC3F7; background: rgba(79,195,247,0.12); }
.ShiftOff     { color: var(--ColorTextMuted); background: rgba(74,92,122,0.1); }

/* ---- Payroll Card ---- */
.PayrollCard {
    background: var(--ColorSurface);
    border: 1px solid var(--ColorBorder);
    border-radius: var(--RadiusCard);
    padding: 20px;
    transition: var(--TransitionFast);
}
.PayrollCard:hover {
    border-color: var(--ColorAccentBlueDim);
    box-shadow: var(--ShadowCard);
}

.PayrollCardName {
    font-family: var(--FontDisplay);
    font-size: 16px;
    font-weight: 600;
    margin-bottom: 12px;
}

.PayrollRow {
    display: flex;
    justify-content: space-between;
    font-size: 13px;
    padding: 5px 0;
    border-bottom: 1px solid rgba(36,48,80,0.5);
}
.PayrollRow:last-child { border-bottom: none; }

.PayrollDeduct { color: var(--ColorDanger); font-weight: 600; }
.PayrollNet    { color: var(--ColorSuccess); font-family: var(--FontDisplay); font-size: 16px; font-weight: 700; }

/* ---- Inventory Category Badge ---- */
.CatWeapons  { color: #EF9A9A; background: rgba(244,67,54,0.1); }
.CatOffice   { color: #90CAF9; background: rgba(33,150,243,0.1); }
.CatBulk     { color: #A5D6A7; background: rgba(76,175,80,0.1); }

/* ---- Loading Spinner ---- */
.Spinner {
    width: 28px;
    height: 28px;
    border: 3px solid var(--ColorBorder);
    border-top-color: var(--ColorAccentGold);
    border-radius: 50%;
    animation: Spin 0.7s linear infinite;
    margin: 30px auto;
    display: block;
}

@keyframes Spin {
    to { transform: rotate(360deg); }
}

/* ---- Empty State ---- */
.EmptyState {
    text-align: center;
    padding: 50px 20px;
    color: var(--ColorTextMuted);
}
.EmptyState .EmptyIcon { font-size: 48px; margin-bottom: 12px; }
.EmptyState p { font-size: 14px; }

/* ---- Responsive ---- */
@media (max-width: 768px) {
    :root { --SidebarWidth: 0px; }
    .SideNav { transform: translateX(-100%); }
    .MainContent { margin-left: 0; }
    .PageContent { padding: 16px; }
    .StatsGrid { grid-template-columns: 1fr 1fr; }
}
```

### includes/db_connect.php
```php
<?php
// =====================================================
// DATABASE CONNECTION - db_connect.php
// Edit the values below to match your phpMyAdmin setup
// =====================================================

define('DB_HOST', 'localhost');
define('DB_USER', 'root');        // your phpMyAdmin username
define('DB_PASS', '');            // your phpMyAdmin password (empty by default in XAMPP)
define('DB_NAME', 'security_firm');

function getConnection() {
    try {
        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,  // Prevents SQL injection
        ];
        $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        return $pdo;
    } catch (PDOException $e) {
        // Send error as JSON so frontend can show it
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => 'Database connection failed: ' . $e->getMessage()]);
        exit;
    }
}
?>
```

### includes/nav.php
```php
<?php
// =====================================================
// SHARED NAVIGATION SIDEBAR - nav.php
// Include this in every page with: include 'includes/nav.php';
// =====================================================
?>
<nav class="SideNav">

    <div class="SideNavBrand">
        <div class="BrandLogo">SF</div>
        <div class="BrandTitle">SecureForce</div>
        <div class="BrandSubtitle">Management System</div>
    </div>

    <div class="SideNavMenu">

        <div class="SideNavSection">
            <div class="SideNavSectionLabel">Main</div>

            <a href="dashboard.php" class="SideNavLink">
                <span class="NavIcon">🏠</span>
                <span>Dashboard</span>
            </a>
        </div>

        <div class="SideNavSection">
            <div class="SideNavSectionLabel">Operations</div>

            <a href="attendance_grid.php" class="SideNavLink">
                <span class="NavIcon">📋</span>
                <span>Daily Attendance</span>
            </a>

            <a href="payroll_hub.php" class="SideNavLink">
                <span class="NavIcon">💰</span>
                <span>Payroll & Salaries</span>
            </a>

            <a href="inventory_hub.php" class="SideNavLink">
                <span class="NavIcon">📦</span>
                <span>Inventory</span>
            </a>
        </div>

    </div>

    <div class="SideNavFooter">
        &copy; 2025 SecureForce System<br>
        Academic Project
    </div>

</nav>
```

## 4. JavaScript Modules

### js/app.js
```javascript
// =====================================================
// SECURITY FIRM - SHARED JAVASCRIPT UTILITIES
// app.js - Used by all pages
// =====================================================

// ---- Highlight active sidebar link ----
function SetActiveNavLink() {
    const CurrentPage = window.location.pathname.split('/').pop();
    document.querySelectorAll('.SideNavLink').forEach(function(Link) {
        const LinkHref = Link.getAttribute('href');
        if (LinkHref && LinkHref === CurrentPage) {
            Link.classList.add('Active');
        }
    });
}

// ---- Show toast notification ----
function ShowToast(Message, Type) {
    Type = Type || 'success'; // 'success' or 'danger'

    let Container = document.getElementById('ToastContainer');
    if (!Container) {
        Container = document.createElement('div');
        Container.id = 'ToastContainer';
        Container.className = 'ToastContainer';
        document.body.appendChild(Container);
    }

    const Toast = document.createElement('div');
    Toast.className = 'Toast Toast' + (Type === 'success' ? 'Success' : 'Danger');

    const Icon = Type === 'success' ? '✅' : '❌';
    Toast.innerHTML = '<span>' + Icon + '</span><span>' + Message + '</span>';

    Container.appendChild(Toast);

    // Auto-remove after 3 seconds
    setTimeout(function() {
        Toast.style.opacity = '0';
        Toast.style.transform = 'translateX(100%)';
        Toast.style.transition = '0.3s ease';
        setTimeout(function() { Toast.remove(); }, 300);
    }, 3000);
}

// ---- Open modal ----
function OpenModal(ModalId) {
    const Modal = document.getElementById(ModalId);
    if (Modal) {
        Modal.classList.add('Open');
        document.body.style.overflow = 'hidden';
    }
}

// ---- Close modal ----
function CloseModal(ModalId) {
    const Modal = document.getElementById(ModalId);
    if (Modal) {
        Modal.classList.remove('Open');
        document.body.style.overflow = '';
    }
}

// ---- Close modal when clicking outside ----
function SetupModalOutsideClick() {
    document.querySelectorAll('.ModalOverlay').forEach(function(Overlay) {
        Overlay.addEventListener('click', function(Event) {
            if (Event.target === Overlay) {
                Overlay.classList.remove('Open');
                document.body.style.overflow = '';
            }
        });
    });
}

// ---- Update date/time display ----
function UpdateDateTime() {
    const DateEl = document.getElementById('CurrentDateTime');
    if (!DateEl) return;

    const Now = new Date();
    const Options = {
        weekday: 'short', year: 'numeric',
        month: 'short', day: 'numeric',
        hour: '2-digit', minute: '2-digit'
    };
    DateEl.textContent = Now.toLocaleDateString('en-PK', Options);
}

// ---- Format currency in PKR ----
function FormatPKR(Amount) {
    return 'PKR ' + parseFloat(Amount).toLocaleString('en-PK', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });
}

// ---- Get initials from name for avatar ----
function GetInitials(Name) {
    const Parts = Name.trim().split(' ');
    if (Parts.length >= 2) {
        return (Parts[0][0] + Parts[1][0]).toUpperCase();
    }
    return Parts[0].substring(0, 2).toUpperCase();
}

// ---- Confirm action with simple dialog ----
function ConfirmAction(Message, OnConfirm) {
    if (window.confirm(Message)) {
        OnConfirm();
    }
}

// ---- Initialize on page load ----
document.addEventListener('DOMContentLoaded', function() {
    SetActiveNavLink();
    SetupModalOutsideClick();
    UpdateDateTime();
    setInterval(UpdateDateTime, 60000); // update every minute
});
```

### js/dashboard.js
```javascript
// =====================================================
// DASHBOARD JAVASCRIPT - dashboard.js
// Handles guard profile view, shift modal, archive
// =====================================================

// ---- Load Guard Profile into Modal ----
function ViewGuardProfile(GuardID) {
    OpenModal('GuardProfileModal');
    document.getElementById('GuardProfileBody').innerHTML = '<div class="Spinner"></div>';

    // Fetch guard data from API
    fetch('api/api_router.php?Action=GetGuardProfile&GuardID=' + GuardID)
        .then(function(Response) { return Response.json(); })
        .then(function(Data) {
            if (Data.success) {
                RenderGuardProfile(Data.guard);
            } else {
                document.getElementById('GuardProfileBody').innerHTML =
                    '<div class="AlertBox AlertDanger">❌ Could not load guard profile. ' + Data.message + '</div>';
            }
        })
        .catch(function() {
            document.getElementById('GuardProfileBody').innerHTML =
                '<div class="AlertBox AlertDanger">❌ Network error. Please try again.</div>';
        });
}

// ---- Render guard profile HTML ----
function RenderGuardProfile(Guard) {
    const Initials = GetInitials(Guard.FullName);

    const ShiftColors = {
        'Morning':  '#FFB74D',
        'Evening':  '#7986CB',
        'Night':    '#4FC3F7',
        'Off Duty': '#607D8B'
    };

    const ShiftColor = ShiftColors[Guard.CurrentShift] || '#607D8B';

    const HTML = `
        <div class="ProfileCardHeader">
            <div class="ProfileAvatar">${Initials}</div>
            <div>
                <div style="font-family: var(--FontDisplay); font-size: 20px; font-weight: 700;">
                    ${Guard.FullName}
                </div>
                <div style="margin-top: 4px;">
                    <span class="Badge" style="color: ${ShiftColor}; background: ${ShiftColor}20;">
                        ${Guard.CurrentShift}
                    </span>
                    <span class="Badge BadgeSuccess" style="margin-left: 6px;">${Guard.Status}</span>
                </div>
            </div>
        </div>

        <div class="ProfileInfoGrid">
            <div class="ProfileInfoItem">
                <div class="InfoKey">🪪 CNIC</div>
                <div class="InfoValue" style="font-family: monospace;">${Guard.CNIC}</div>
            </div>
            <div class="ProfileInfoItem">
                <div class="InfoKey">🩸 Blood Group</div>
                <div class="InfoValue">
                    <span class="Badge BadgeWarning">${Guard.BloodGroup || 'Not Set'}</span>
                </div>
            </div>
            <div class="ProfileInfoItem">
                <div class="InfoKey">📱 Phone</div>
                <div class="InfoValue">${Guard.Phone || 'Not Provided'}</div>
            </div>
            <div class="ProfileInfoItem">
                <div class="InfoKey">🚨 Emergency Contact</div>
                <div class="InfoValue">${Guard.EmergencyPhone || 'Not Provided'}</div>
            </div>
            <div class="ProfileInfoItem">
                <div class="InfoKey">📅 Joined On</div>
                <div class="InfoValue">${Guard.JoiningDate}</div>
            </div>
            <div class="ProfileInfoItem">
                <div class="InfoKey">📍 Address</div>
                <div class="InfoValue">${Guard.Address || 'Not Provided'}</div>
            </div>
        </div>
    `;

    document.getElementById('GuardProfileBody').innerHTML = HTML;
}

// ---- Open Shift Change Modal ----
function OpenShiftModal(GuardID, GuardName) {
    document.getElementById('ShiftGuardID').value = GuardID;
    document.getElementById('ShiftGuardName').textContent = GuardName;
    OpenModal('ShiftModal');
}

// ---- Archive Guard ----
function ArchiveGuard(GuardID, GuardName) {
    ConfirmAction(
        'Are you sure you want to archive "' + GuardName + '"?\n\nThey will be removed from active duty but records will be kept.',
        function() {
            document.getElementById('ArchiveGuardID').value = GuardID;
            document.getElementById('ArchiveForm').submit();
        }
    );
}
```

### js/attendance.js
```javascript
// =====================================================
// ATTENDANCE JAVASCRIPT - attendance.js
// Handles fines, locking rows, present toggle
// =====================================================

// ---- Recalculate displayed fine total when checkboxes change ----
function RecalcFine(AttendanceID) {
    const Checkboxes = document.querySelectorAll('.FineCheck[data-aid="' + AttendanceID + '"]');
    let Total = 0;

    Checkboxes.forEach(function(CB) {
        if (CB.checked) {
            Total += parseFloat(CB.dataset.amount || 0);
        }
    });

    const TotalEl = document.getElementById('TotalFine_' + AttendanceID);
    if (TotalEl) {
        TotalEl.textContent = 'PKR ' + Total.toLocaleString();
        TotalEl.style.color = Total > 0 ? '#F44336' : '#4CAF50';
    }
}

// ---- Toggle present/absent ----
function TogglePresent(AttendanceID, IsPresent) {
    const Data = new FormData();
    Data.append('Action', 'TogglePresent');
    Data.append('AttendanceID', AttendanceID);
    Data.append('IsPresent', IsPresent ? 1 : 0);

    fetch('api/api_router.php', { method: 'POST', body: Data })
        .then(function(Res) { return Res.json(); })
        .then(function(Data) {
            if (Data.success) {
                ShowToast('Attendance updated!', 'success');
            } else {
                ShowToast('Error: ' + Data.message, 'danger');
            }
        });
}

// ---- Lock attendance row ----
function LockRow(AttendanceID) {
    // Get checkbox states for all fines
    const UniformCB = document.getElementById('Uniform_' + AttendanceID);
    const WeaponCB  = document.getElementById('Weapon_'  + AttendanceID);
    const LateCB    = document.getElementById('Late_'    + AttendanceID);
    const ConductCB = document.getElementById('Conduct_' + AttendanceID);
    const PresentCB = document.getElementById('Present_' + AttendanceID);

    const UniformFine = (UniformCB && UniformCB.checked) ? parseFloat(UniformCB.dataset.amount) : 0;
    const WeaponFine  = (WeaponCB  && WeaponCB.checked)  ? parseFloat(WeaponCB.dataset.amount)  : 0;
    const LateFine    = (LateCB    && LateCB.checked)    ? parseFloat(LateCB.dataset.amount)    : 0;
    const ConductFine = (ConductCB && ConductCB.checked) ? parseFloat(ConductCB.dataset.amount) : 0;
    const IsPresent   = (PresentCB && PresentCB.checked) ? 1 : 0;

    const Data = new FormData();
    Data.append('Action',        'LockAttendance');
    Data.append('AttendanceID',  AttendanceID);
    Data.append('UniformFine',   UniformFine);
    Data.append('WeaponFine',    WeaponFine);
    Data.append('LateFine',      LateFine);
    Data.append('ConductFine',   ConductFine);
    Data.append('IsPresent',     IsPresent);

    fetch('api/api_router.php', { method: 'POST', body: Data })
        .then(function(Res) { return Res.json(); })
        .then(function(Resp) {
            if (Resp.success) {
                ShowToast('Row locked! Fine: PKR ' + Resp.TotalFine, 'success');

                // Update UI to show locked state
                const Row = document.getElementById('Row_' + AttendanceID);
                if (Row) {
                    Row.style.opacity = '0.7';

                    // Disable all checkboxes in this row
                    Row.querySelectorAll('input[type="checkbox"]').forEach(function(CB) {
                        CB.disabled = true;
                    });

                    // Replace lock button with "Done" text
                    const LockBtn = Row.querySelector('button');
                    if (LockBtn) {
                        LockBtn.outerHTML = '<span style="color: var(--ColorTextMuted); font-size: 12px;">Done</span>';
                    }

                    // Update status badge
                    const StatusCell = Row.cells[9];
                    if (StatusCell) {
                        StatusCell.innerHTML = '<span class="Badge BadgeMuted">🔒 Locked</span>';
                    }
                }
            } else {
                ShowToast('Error: ' + Resp.message, 'danger');
            }
        })
        .catch(function() {
            ShowToast('Network error. Please try again.', 'danger');
        });
}
```

### js/payroll.js
```javascript
// =====================================================
// PAYROLL JAVASCRIPT - payroll.js
// Handles generate payroll and mark as paid actions
// =====================================================

// ---- Generate payroll for selected month ----
function GeneratePayroll() {
    const Month = document.getElementById('MonthPicker').value;

    if (!Month) {
        ShowToast('Please select a month first!', 'danger');
        return;
    }

    const Data = new FormData();
    Data.append('Action',   'GeneratePayroll');
    Data.append('PayMonth', Month);

    ShowToast('Generating payroll... please wait ⏳', 'success');

    fetch('api/api_router.php', { method: 'POST', body: Data })
        .then(function(Res) { return Res.json(); })
        .then(function(Resp) {
            if (Resp.success) {
                ShowToast('✅ ' + Resp.message, 'success');
                setTimeout(function() {
                    window.location.href = 'payroll_hub.php?month=' + Month;
                }, 1500);
            } else {
                ShowToast('❌ ' + Resp.message, 'danger');
            }
        })
        .catch(function() {
            ShowToast('Network error. Please try again.', 'danger');
        });
}

// ---- Mark payroll record as paid ----
function MarkAsPaid(PayrollID) {
    const Data = new FormData();
    Data.append('Action',    'MarkPaid');
    Data.append('PayrollID', PayrollID);

    fetch('api/api_router.php', { method: 'POST', body: Data })
        .then(function(Res) { return Res.json(); })
        .then(function(Resp) {
            if (Resp.success) {
                ShowToast('✅ Marked as paid!', 'success');

                // Update UI without page reload
                const Card = document.getElementById('PayCard_' + PayrollID);
                if (Card) {
                    const NameEl = Card.querySelector('.PayrollCardName');
                    if (NameEl && !NameEl.querySelector('.Badge')) {
                        NameEl.innerHTML += ' <span class="Badge BadgeSuccess" style="font-size: 10px; vertical-align: middle; margin-left: 6px;">PAID</span>';
                    }

                    const Btn = Card.querySelector('button');
                    if (Btn) {
                        Btn.remove();
                    }
                }
            } else {
                ShowToast('Error: ' + Resp.message, 'danger');
            }
        });
}
```

### js/inventory.js
```javascript
// =====================================================
// INVENTORY JAVASCRIPT - inventory.js
// Handles update quantity modal and archive actions
// =====================================================

// ---- Open update quantity modal ----
function OpenUpdateModal(ItemID, ItemName, CurrentQty) {
    document.getElementById('UpdateItemID').value   = ItemID;
    document.getElementById('UpdateItemName').textContent = ItemName;
    document.getElementById('UpdateQtyInput').value = CurrentQty;
    OpenModal('UpdateQtyModal');
}

// ---- Archive/Remove item ----
function ArchiveItem(ItemID, ItemName) {
    ConfirmAction(
        'Remove "' + ItemName + '" from inventory?\n\nThe record will be archived (not deleted permanently).',
        function() {
            document.getElementById('ArchiveItemID').value = ItemID;
            document.getElementById('ArchiveItemForm').submit();
        }
    );
}
```
